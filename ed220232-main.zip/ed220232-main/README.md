# ed220232
Disciplina de Estrutura de Dados 2 do Curso de Bacharelado em Engenharia da Computação.

# Execução do ambiente de desenvolvimento
Para executar o ambiente de desenvolvimento:
```shell
docker run --name c_ide -p 0.0.0.0:8080:8080 -it jppreti/ed2
```

# Ajuda
Para obter ajuda no processo de compilação e execução:
```shell
make help
```
